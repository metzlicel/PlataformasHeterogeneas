# cetys-icc-hetplat
Code related to the Heterogenous Platforms Development course at CETYS Universidad
