using HttpMessageParser.Models;

namespace HttpMessageParser;

public class HttpResponseWriter : IResponseWriter
{
    public string WriteResponse(HttpResponse response)
    {
        // Si el request o parametros es null
        if (response == null)
        {
            throw new ArgumentNullException(nameof(response), "The response text cannot be null.");
        }
        else if (response.Protocol == null || response.StatusCode == null || response.StatusText == null)
        {
            throw new ArgumentException("The response is missing parameters.");
        }
        
        // Extraer mensaje por partes
        string responseProtocol = response.Protocol;;
        int statusCode = response.StatusCode;
        string statusText = response.StatusText;

        List<string> responseHeaders = new List<string>();

        if (response.Headers != null)
        {
            foreach (var (key, value) in response.Headers)
            {
                responseHeaders.Add($"{key}: {value}");
            }
        }

        string responseBody = null;

        if (response.Body != null)
        {
            responseBody = $"\n{response.Body}";
        }

        // Concatenar datos y regresar el string
        string headersText = null;
        if (responseHeaders.Count > 0)
        {
            headersText = string.Join("\n", responseHeaders);
        }
        
        string responseText = $"{responseProtocol} {statusCode} {statusText}\n{headersText}\n{responseBody}";


    return responseText;
    }
}