using HttpMessageParser.Models;

namespace HttpMessageParser;

public class HttpRequestParser : IRequestParser
{ 
    public HttpRequest ParseRequest(string requestText)
    {
        // Si el request es null
        if (requestText == null)
        {
            throw new ArgumentNullException(nameof(requestText), "The request text cannot be null.");
        }
       
        // Si el request esta vacio
        if (string.IsNullOrWhiteSpace(requestText))
        {
            throw new ArgumentException("The request text cannot be empty.");
        }
       
        var text  = requestText.Replace("\r\n", "\n"); //Quitar saltos de linea
        var lines = text.Split('\n'); // Separar por renglon
        
        var requestLine = lines[0].Trim(); // Toma la primera linea y le quita espacios/saltos
        var parts = requestLine.Split(' ', StringSplitOptions.RemoveEmptyEntries); // Guarda las palabras separadas 
        
        
        Dictionary<string, string> headers = new Dictionary<string, string>();
        string body = null;
        HttpRequest request = null;
            
        // Si el request minimo NO es igual a 3 partes
        // Ej: "GET /index.html HTTP/1.1"
        if (parts.Length != 3)
            throw new ArgumentException("The request is not valid.");
        
        string method = parts[0];
        string requestTarget = parts[1];
        string protocol = parts[2];
        
        //Validar antes de crear y regresar objeto
        if (method.Any(char.IsLower))
            throw new ArgumentException("HTTP method must be uppercase.", nameof(requestText));
        
        if (!requestTarget.StartsWith("/", StringComparison.Ordinal))
            throw new ArgumentException("Invalid request target.");
        
        if (!protocol.StartsWith("HTTP/", StringComparison.Ordinal))
            throw new ArgumentException("Invalid protocol.");
        
        // Aceptar minimal request
        if (lines.Length == 1)
        {
            request = new HttpRequest
            {
                Method = method,
                RequestTarget = requestTarget,
                Protocol = protocol,
                Headers = new Dictionary<string, string>(), // vacío
                Body = null
            };
        }
        // Si hay mas contenido
        else if (lines.Length > 1)
        {
            // Validar Headers
            // Ej: "Host: example.com\n" +
            // "User-Agent: some-user-agent"
            int lastHeader = 0;
            for (int i = 1; i < lines.Length; i++) //Validar si hay varios headers
            {
                var line = lines[i];
                if (line.Length == 0)
                {
                    lastHeader = i;
                    i++; 
                    break; // linea en blanco, fin headers
                }  

                int colon = line.IndexOf(':'); // Buscar ":"
                if (colon <= 0)
                    throw new ArgumentException($"Invalid header line: '{line}'"); 

                var name  = line[..colon].Trim();            // "Host"
                var value = line[(colon + 1)..].Trim();      // "example.com"
                headers[name] = value;
            }
            
            // Validar Body
            // Ej: "\n" +
            // "{\"key\": \"value\"}";
            if (lastHeader < lines.Length) {
                body = string.Join("\n", lines.Skip(lastHeader + 1)); // Siempre despues del ultimo header habra un espacio que hay que saltar, por eso el +1
                if (body.Length == 0) body = null;
            }
        }
        else
        {
            throw new ArgumentException("The request is not valid.");
        }
        
        // Crear y regresar el objeto request
        request = new HttpRequest
        {
            Method = method, 
            RequestTarget = requestTarget,   
            Protocol = protocol, 
            Headers = headers,   
            Body = body
        };
    return request;
    }
}