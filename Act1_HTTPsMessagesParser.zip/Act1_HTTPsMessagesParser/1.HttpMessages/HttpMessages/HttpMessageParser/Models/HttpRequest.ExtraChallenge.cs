﻿namespace HttpMessageParser.Models
{
    public partial class HttpRequest
    {
        /// <summary>
        /// Returns the value of a specific header from the request. This is case-insensitive.
        /// </summary>
        /// <param name="headerName">The name of the header to retrieve.</param>
        /// <returns>
        /// The value of the specified header if it exists; otherwise, null.
        /// </returns>
        /// <exception cref="ArgumentException">If the <paramref name="headerName"/> is null or empty.</exception>"
        public string GetHeaderValue(string headerName)
        {
            // Si es null o un header vacio
            if (headerName == null)
            {
                throw new ArgumentException("Header is null");
            }
            else if (string.IsNullOrEmpty(headerName))
            {
                throw new ArgumentException("Header name is null or empty");
            }
            
            // Crear una copia de Headers y la vuelve un diccionario case insensitive
            var caseInsensitiveHeaders = new Dictionary<string, string>(Headers, StringComparer.OrdinalIgnoreCase);
                    
            // Buscar value by key (headerName)
            string headerValue = null;
            // Case insensitive
            if (caseInsensitiveHeaders.ContainsKey(headerName)) 
            {
                headerValue = caseInsensitiveHeaders[headerName];
            }
           return headerValue;
        }

        /// <summary>
        /// Extracts the query parameters from the <c>RequestTarget</c> property.
        /// </summary>
        /// <remarks>
        /// If no query parameters are present, this method will return an empty dictionary.
        /// </remarks>
        /// <returns>
        /// A dictionary where the keys are the parameter names and the values are the parameter values.
        /// </returns>
        /// <exception cref="FormatException">If the <c>RequestTarget</c> contains query parameters, but they are malformed.</exception>"
        public Dictionary<string, string> GetQueryParameters()
        {
            Dictionary<string, string> parameters = new Dictionary<string, string>();

            int questionMark = RequestTarget.IndexOf('?'); // Buscar "?"
            if (questionMark < 0)
            {
                return parameters; // parameters vacio
            }
            
            // Ej: "/path?param1=value1&param2=value2"
            var text  = RequestTarget.Replace("?", "\n"); //Quitar "?"
            var lines = text.Split('\n'); // Separar por renglon
            
            string prmts = lines[1]; // Tomar solo lo que esta despues de "?"
            prmts = prmts.Replace("&", "\n"); // Quitar "&"
            var prmtsLines = prmts.Split('\n'); // Separar por renglon
           

            for (int i = 0; i < prmtsLines.Length; i++)
            {
                int equalSign = prmtsLines[i].IndexOf('='); // Buscar el "="

                if (equalSign > 0) // Si si hay key value pairs
                {
                    var key= prmtsLines[i][..equalSign].Trim(); // Antes de "=" es key
                    var value= prmtsLines[i][(equalSign + 1)..].Trim(); 
             
                    parameters[key] = value;
                }
                else
                {
                    throw new FormatException("Incorrect parameter format");
                }
                
            }
          
            return parameters;
        }

        /// <summary>
        /// Extracts the form data from the request body. This supports both the "application/x-www-form-urlencoded" 
        /// and the "multipart/form-data" content types.
        /// </summary>
        /// <remarks>
        /// If the request has no body or the body does not contain form data, this method will return an empty dictionary.
        /// </remarks>
        /// <returns>
        /// A dictionary where the keys are the form field names and the values are the form field values.
        /// </returns>
        /// <exception cref="FormatException">If the contents of the body are not in the correct format.</exception>
        public Dictionary<string, string> GetFormData()
        {
            Dictionary<string, string> formData = new Dictionary<string, string>();
            if (Body == null)
            {
                return formData;
            }
            
            string urlEncode = null;
            string multiFormData = null;

            // Si existe el header
            if (Headers.ContainsKey("Content-Type"))
            {
                // Si es form url encoded
                if (Headers["Content-Type"] == "application/x-www-form-urlencoded")
                {
                    // Ej: "field1=value1&field2=value2"
                   string body = Body;
                   urlEncode = body.Replace("&", "\n"); // Quitar "&"
                   var urlLines = urlEncode.Split('\n'); // Separar por renglon

                   for (int i = 0; i < urlLines.Length; i++)
                   {
                       int equalSign = urlLines[i].IndexOf('='); // Buscar el "="

                       if (equalSign > 0) // Si si hay key value pairs
                       {
                           var key= urlLines[i][..equalSign].Trim(); // Antes de "=" es key
                           var value= urlLines[i][(equalSign + 1)..].Trim(); 
             
                           formData[key] = value;
                       }
                       else
                       {
                           throw new FormatException("Incorrect parameter format");
                       }
                   }
                }
                // Si es multipart form data
                else if (Headers.ContainsKey("Content-Type") && Headers["Content-Type"].StartsWith("multipart/form-data", StringComparison.OrdinalIgnoreCase))
                {
                    string boundary = "1234567890"; // Donde empieza cada key value

                    // Reemplazar saltos de línea del body
                    string body = (Body ?? string.Empty).Replace("\r\n", "\n").Replace("\r", "\n");

                    // Separar por --1234567890
                    string limite = "--" + boundary;
                    var parts = body.Split(new[] { limite }, StringSplitOptions.None);

                    // Procesar cada parte
                    for (int i = 0; i < parts.Length; i++)
                    {
                        var part = parts[i].Trim(); // Limpia extremos

                        if (string.IsNullOrEmpty(part) || part == "--")
                            continue; // Ignora vacío y cierre final

                        // Buscar name="..."
                        string nameKey = "name=\"";
                        int nameIndex = part.IndexOf(nameKey, StringComparison.OrdinalIgnoreCase);
                        if (nameIndex < 0)
                        {
                            throw new FormatException("Name is required.");

                        }

                        int start = nameIndex + nameKey.Length;
                        int endQuote = part.IndexOf('"', start);
                        if (endQuote < 0)
                        {
                            throw new FormatException("Malformed name.");
                        }

                        string key = part.Substring(start, endQuote - start);

                        // Lo que está después de la línea en blanco (\n\n)
                        int space = part.IndexOf("\n\n", endQuote, StringComparison.Ordinal);
                        if (space < 0) throw new FormatException("Header/body separator not found.");

                        string value = part[(space + 2)..].TrimEnd('\n');

                        formData[key] = value;
                    }
                }
            }
            return formData;
        }
    }
}
