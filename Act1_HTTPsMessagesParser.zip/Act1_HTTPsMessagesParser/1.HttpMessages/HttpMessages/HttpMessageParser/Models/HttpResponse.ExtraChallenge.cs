﻿namespace HttpMessageParser.Models
{
    public partial class HttpResponse
    {
        /// <summary>
        /// Returns the value of a specific header from the request. This is case-insensitive.
        /// </summary>
        /// <param name="headerName">The name of the header to retrieve.</param>
        /// <returns>
        /// The value of the specified header if it exists; otherwise, null.
        /// </returns>
        /// <exception cref="ArgumentException">If the <paramref name="headerName"/> is null or empty.</exception>"
        public string GetHeaderValue(string headerName)
        {
            // Si es null o un header vacio
            if (headerName == null)
            {
                throw new ArgumentException("Header is null");
            }
            else if (string.IsNullOrEmpty(headerName))
            {
                throw new ArgumentException("Header name is null or empty");
            }
            
            // Crear una copia de Headers y la vuelve un diccionario case insensitive
            var caseInsensitiveHeaders = new Dictionary<string, string>(Headers, StringComparer.OrdinalIgnoreCase);
                    
            // Buscar value by key (headerName)
            string headerValue = null;
            // Case insensitive
            if (caseInsensitiveHeaders.ContainsKey(headerName)) 
            {
                headerValue = caseInsensitiveHeaders[headerName];
            }
            return headerValue;
        }

        /// <summary>
        /// Returns a boolean indicating whether the response is successful.
        /// </summary>
        /// <returns>
        /// True if the status code indicates a success, otherwise false.
        /// </returns>
        public bool IsSuccess()
        {
            if (StatusCode >= 200 && StatusCode < 300)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Returns a boolean indicating whether the response is a client error.
        /// </summary>
        /// <returns>
        /// True if the status code indicates a client error, otherwise false.
        /// </returns>
        public bool IsClientError()
        {
            if (StatusCode >= 400 && StatusCode < 500)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Returns a boolean indicating whether the response is a server error.
        /// </summary>
        /// <returns>
        /// True if the status code indicates a server error, otherwise false.
        /// </returns>
        public bool IsServerError()
        {
            if (StatusCode >= 500 && StatusCode < 600)
            {
                return true;
            }
            return false;
        }
    }
}
